import addClasses from './addClasses.mjs';
import removeClasses from './removeClasses.mjs';

export default { addClasses, removeClasses };
