import Swiper from './core/core.mjs';
//IMPORT_MODULES

// eslint-disable-next-line
export { default as Swiper, default } from './core/core.mjs';

// Swiper Class
const modules = [
  //INSTALL_MODULES
];
Swiper.use(modules);
